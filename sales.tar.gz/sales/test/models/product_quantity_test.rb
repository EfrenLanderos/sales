require 'test_helper'

class ProductQuantityTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
