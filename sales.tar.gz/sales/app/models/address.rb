class Address < ApplicationRecord
  belongs_to :client
end
